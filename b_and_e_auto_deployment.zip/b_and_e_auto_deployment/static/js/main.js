// B&E Auto - Main JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const mainNav = document.querySelector('.main-nav');
    
    if (mobileMenuToggle) {
        mobileMenuToggle.addEventListener('click', function() {
            mainNav.classList.toggle('active');
        });
    }
    
    // Testimonial slider
    const testimonials = document.querySelectorAll('.testimonial');
    const prevButton = document.querySelector('.testimonial-prev');
    const nextButton = document.querySelector('.testimonial-next');
    
    if (testimonials.length > 0 && prevButton && nextButton) {
        let currentTestimonial = 0;
        
        // Show only the current testimonial
        function showTestimonial(index) {
            testimonials.forEach((testimonial, i) => {
                testimonial.style.display = i === index ? 'block' : 'none';
            });
        }
        
        // Initialize with the first testimonial
        showTestimonial(currentTestimonial);
        
        // Previous button click
        prevButton.addEventListener('click', function() {
            currentTestimonial = (currentTestimonial - 1 + testimonials.length) % testimonials.length;
            showTestimonial(currentTestimonial);
        });
        
        // Next button click
        nextButton.addEventListener('click', function() {
            currentTestimonial = (currentTestimonial + 1) % testimonials.length;
            showTestimonial(currentTestimonial);
        });
        
        // Auto-rotate testimonials every 5 seconds
        setInterval(function() {
            currentTestimonial = (currentTestimonial + 1) % testimonials.length;
            showTestimonial(currentTestimonial);
        }, 5000);
    }
    
    // Reset filter button
    const resetFilterBtn = document.querySelector('.reset-filter-btn');
    
    if (resetFilterBtn) {
        resetFilterBtn.addEventListener('click', function() {
            const filterSelects = document.querySelectorAll('.search-form select');
            filterSelects.forEach(select => {
                select.selectedIndex = 0;
            });
        });
    }
    
    // Admin dashboard functionality
    if (window.location.pathname.includes('/admin')) {
        // Photo upload preview
        const photoInput = document.getElementById('photo-upload');
        const photoPreview = document.getElementById('photo-preview');
        
        if (photoInput && photoPreview) {
            photoInput.addEventListener('change', function() {
                if (this.files && this.files[0]) {
                    const reader = new FileReader();
                    
                    reader.onload = function(e) {
                        photoPreview.src = e.target.result;
                        photoPreview.style.display = 'block';
                    };
                    
                    reader.readAsDataURL(this.files[0]);
                }
            });
        }
        
        // AI Photo Editor
        const editButtons = document.querySelectorAll('.edit-photo-btn');
        const photoEditor = document.getElementById('photo-editor');
        const editorImage = document.getElementById('editor-image');
        const saveEditBtn = document.getElementById('save-edit-btn');
        const cancelEditBtn = document.getElementById('cancel-edit-btn');
        const backgroundOptions = document.querySelectorAll('.photo-editor-background');
        
        if (editButtons.length > 0 && photoEditor && editorImage) {
            // Open editor when edit button is clicked
            editButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const photoId = this.dataset.photoId;
                    const photoSrc = this.dataset.photoSrc;
                    
                    editorImage.src = photoSrc;
                    editorImage.dataset.photoId = photoId;
                    
                    photoEditor.style.display = 'block';
                });
            });
            
            // Close editor when cancel button is clicked
            if (cancelEditBtn) {
                cancelEditBtn.addEventListener('click', function() {
                    photoEditor.style.display = 'none';
                });
            }
            
            // Select background
            if (backgroundOptions.length > 0) {
                backgroundOptions.forEach(option => {
                    option.addEventListener('click', function() {
                        // Remove active class from all options
                        backgroundOptions.forEach(opt => opt.classList.remove('active'));
                        
                        // Add active class to selected option
                        this.classList.add('active');
                    });
                });
            }
            
            // Save edited photo
            if (saveEditBtn) {
                saveEditBtn.addEventListener('click', function() {
                    // In a real implementation, this would send the edited photo to the server
                    // For demo purposes, we'll just close the editor
                    photoEditor.style.display = 'none';
                    
                    // Show success message
                    alert('Photo edited successfully!');
                });
            }
        }
    }
});
