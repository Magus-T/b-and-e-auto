from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, session
from src.models.models import User, Vehicle, VehiclePhoto, Inquiry, TradeIn, BackgroundImage, SiteSettings
from src.main import db, save_uploaded_file
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
import os
import json
from datetime import datetime

admin_bp = Blueprint('admin', __name__)

# Authentication decorator
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to access this page', 'warning')
            return redirect(url_for('admin.login'))
        return f(*args, **kwargs)
    return decorated_function

# Login route
@admin_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        
        if user and check_password_hash(user.password_hash, password):
            session['user_id'] = user.id
            session['username'] = user.username
            session['role'] = user.role
            
            # Update last login time
            user.last_login = datetime.utcnow()
            db.session.commit()
            
            flash('Login successful!', 'success')
            return redirect(url_for('admin.dashboard'))
        else:
            flash('Invalid username or password', 'danger')
    
    return render_template('admin/login.html')

# Logout route
@admin_bp.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out', 'info')
    return redirect(url_for('admin.login'))

# Dashboard home
@admin_bp.route('/')
@login_required
def dashboard():
    # Get dashboard statistics
    vehicle_count = Vehicle.query.count()
    available_count = Vehicle.query.filter_by(status='available').count()
    pending_count = Vehicle.query.filter_by(status='pending').count()
    sold_count = Vehicle.query.filter_by(status='sold').count()
    
    # Get recent inquiries
    recent_inquiries = Inquiry.query.order_by(Inquiry.created_at.desc()).limit(5).all()
    
    # Get recently added vehicles
    recent_vehicles = Vehicle.query.order_by(Vehicle.created_at.desc()).limit(5).all()
    
    return render_template('admin/dashboard.html', 
                          vehicle_count=vehicle_count,
                          available_count=available_count,
                          pending_count=pending_count,
                          sold_count=sold_count,
                          recent_inquiries=recent_inquiries,
                          recent_vehicles=recent_vehicles)

# Inventory management
@admin_bp.route('/inventory')
@login_required
def inventory():
    # Get filter parameters
    status = request.args.get('status', 'all')
    make = request.args.get('make', 'all')
    sort = request.args.get('sort', 'newest')
    
    # Base query
    query = Vehicle.query
    
    # Apply filters
    if status != 'all':
        query = query.filter_by(status=status)
    
    if make != 'all':
        query = query.filter_by(make=make)
    
    # Apply sorting
    if sort == 'newest':
        query = query.order_by(Vehicle.created_at.desc())
    elif sort == 'oldest':
        query = query.order_by(Vehicle.created_at)
    elif sort == 'price_high':
        query = query.order_by(Vehicle.price.desc())
    elif sort == 'price_low':
        query = query.order_by(Vehicle.price)
    
    # Get distinct makes for filter dropdown
    makes = db.session.query(Vehicle.make).distinct().all()
    makes = [make[0] for make in makes]
    
    # Pagination
    page = request.args.get('page', 1, type=int)
    per_page = 10
    vehicles = query.paginate(page=page, per_page=per_page)
    
    return render_template('admin/inventory.html', 
                          vehicles=vehicles,
                          makes=makes,
                          current_status=status,
                          current_make=make,
                          current_sort=sort)

# Add new vehicle
@admin_bp.route('/inventory/add', methods=['GET', 'POST'])
@login_required
def add_vehicle():
    if request.method == 'POST':
        try:
            # Extract form data
            stock_number = request.form.get('stock_number')
            vin = request.form.get('vin')
            year = request.form.get('year')
            make = request.form.get('make')
            model = request.form.get('model')
            trim = request.form.get('trim')
            body_type = request.form.get('body_type')
            exterior_color = request.form.get('exterior_color')
            interior_color = request.form.get('interior_color')
            mileage = request.form.get('mileage')
            price = request.form.get('price')
            engine = request.form.get('engine')
            transmission = request.form.get('transmission')
            drivetrain = request.form.get('drivetrain')
            fuel_type = request.form.get('fuel_type')
            mpg_city = request.form.get('mpg_city')
            mpg_highway = request.form.get('mpg_highway')
            description = request.form.get('description')
            features = request.form.get('features')
            status = request.form.get('status')
            is_featured = 'is_featured' in request.form
            
            # Validate required fields
            if not all([stock_number, vin, year, make, model, mileage, price]):
                flash('Please fill in all required fields', 'danger')
                return redirect(url_for('admin.add_vehicle'))
            
            # Create new vehicle
            new_vehicle = Vehicle(
                stock_number=stock_number,
                vin=vin,
                year=year,
                make=make,
                model=model,
                trim=trim,
                body_type=body_type,
                exterior_color=exterior_color,
                interior_color=interior_color,
                mileage=mileage,
                price=price,
                engine=engine,
                transmission=transmission,
                drivetrain=drivetrain,
                fuel_type=fuel_type,
                mpg_city=mpg_city if mpg_city else None,
                mpg_highway=mpg_highway if mpg_highway else None,
                description=description,
                features=features,
                status=status,
                is_featured=is_featured
            )
            
            db.session.add(new_vehicle)
            db.session.commit()
            
            flash(f'Vehicle {new_vehicle.title} added successfully!', 'success')
            return redirect(url_for('admin.edit_vehicle', vehicle_id=new_vehicle.id))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error adding vehicle: {str(e)}', 'danger')
    
    return render_template('admin/add_vehicle.html')

# Edit vehicle
@admin_bp.route('/inventory/edit/<int:vehicle_id>', methods=['GET', 'POST'])
@login_required
def edit_vehicle(vehicle_id):
    vehicle = Vehicle.query.get_or_404(vehicle_id)
    
    if request.method == 'POST':
        try:
            # Extract form data
            vehicle.stock_number = request.form.get('stock_number')
            vehicle.vin = request.form.get('vin')
            vehicle.year = request.form.get('year')
            vehicle.make = request.form.get('make')
            vehicle.model = request.form.get('model')
            vehicle.trim = request.form.get('trim')
            vehicle.body_type = request.form.get('body_type')
            vehicle.exterior_color = request.form.get('exterior_color')
            vehicle.interior_color = request.form.get('interior_color')
            vehicle.mileage = request.form.get('mileage')
            vehicle.price = request.form.get('price')
            vehicle.engine = request.form.get('engine')
            vehicle.transmission = request.form.get('transmission')
            vehicle.drivetrain = request.form.get('drivetrain')
            vehicle.fuel_type = request.form.get('fuel_type')
            vehicle.mpg_city = request.form.get('mpg_city')
            vehicle.mpg_highway = request.form.get('mpg_highway')
            vehicle.description = request.form.get('description')
            vehicle.features = request.form.get('features')
            vehicle.status = request.form.get('status')
            vehicle.is_featured = 'is_featured' in request.form
            
            # Validate required fields
            if not all([vehicle.stock_number, vehicle.vin, vehicle.year, vehicle.make, vehicle.model, vehicle.mileage, vehicle.price]):
                flash('Please fill in all required fields', 'danger')
                return redirect(url_for('admin.edit_vehicle', vehicle_id=vehicle_id))
            
            db.session.commit()
            
            flash(f'Vehicle {vehicle.title} updated successfully!', 'success')
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error updating vehicle: {str(e)}', 'danger')
    
    return render_template('admin/edit_vehicle.html', vehicle=vehicle)

# Delete vehicle
@admin_bp.route('/inventory/delete/<int:vehicle_id>', methods=['POST'])
@login_required
def delete_vehicle(vehicle_id):
    vehicle = Vehicle.query.get_or_404(vehicle_id)
    
    try:
        # Delete associated photos from filesystem
        for photo in vehicle.photos:
            try:
                file_path = os.path.join('src/static', photo.file_path.lstrip('/static/'))
                if os.path.exists(file_path):
                    os.remove(file_path)
                
                if photo.original_path:
                    original_path = os.path.join('src/static', photo.original_path.lstrip('/static/'))
                    if os.path.exists(original_path):
                        os.remove(original_path)
            except Exception as e:
                print(f"Error deleting photo file: {str(e)}")
        
        # Delete vehicle from database (cascade will delete photos)
        db.session.delete(vehicle)
        db.session.commit()
        
        flash(f'Vehicle {vehicle.title} deleted successfully!', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Error deleting vehicle: {str(e)}', 'danger')
    
    return redirect(url_for('admin.inventory'))

# Vehicle photos management
@admin_bp.route('/inventory/photos/<int:vehicle_id>', methods=['GET', 'POST'])
@login_required
def manage_photos(vehicle_id):
    vehicle = Vehicle.query.get_or_404(vehicle_id)
    
    if request.method == 'POST':
        try:
            # Handle photo upload
            if 'photos' in request.files:
                files = request.files.getlist('photos')
                
                for file in files:
                    if file.filename:
                        file_path = save_uploaded_file(file)
                        
                        if file_path:
                            # Create new photo record
                            new_photo = VehiclePhoto(
                                vehicle_id=vehicle.id,
                                file_path=file_path,
                                file_name=os.path.basename(file_path),
                                original_path=file_path  # Store original path for AI editing
                            )
                            
                            # If this is the first photo, make it primary
                            if not vehicle.photos:
                                new_photo.is_primary = True
                            
                            db.session.add(new_photo)
                
                db.session.commit()
                flash('Photos uploaded successfully!', 'success')
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error uploading photos: {str(e)}', 'danger')
    
    # Get background images for AI editing
    backgrounds = BackgroundImage.query.filter_by(is_active=True).all()
    
    return render_template('admin/manage_photos.html', vehicle=vehicle, backgrounds=backgrounds)

# Set primary photo
@admin_bp.route('/inventory/photos/set-primary', methods=['POST'])
@login_required
def set_primary_photo():
    photo_id = request.form.get('photo_id')
    vehicle_id = request.form.get('vehicle_id')
    
    if not photo_id or not vehicle_id:
        return jsonify({'success': False, 'message': 'Missing required parameters'})
    
    try:
        # Reset all photos for this vehicle
        VehiclePhoto.query.filter_by(vehicle_id=vehicle_id).update({'is_primary': False})
        
        # Set the selected photo as primary
        photo = VehiclePhoto.query.get(photo_id)
        if photo:
            photo.is_primary = True
            db.session.commit()
            return jsonify({'success': True})
        else:
            return jsonify({'success': False, 'message': 'Photo not found'})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)})

# Delete photo
@admin_bp.route('/inventory/photos/delete', methods=['POST'])
@login_required
def delete_photo():
    photo_id = request.form.get('photo_id')
    
    if not photo_id:
        return jsonify({'success': False, 'message': 'Missing photo ID'})
    
    try:
        photo = VehiclePhoto.query.get(photo_id)
        
        if photo:
            # Delete file from filesystem
            try:
                file_path = os.path.join('src/static', photo.file_path.lstrip('/static/'))
                if os.path.exists(file_path):
                    os.remove(file_path)
                
                if photo.original_path:
                    original_path = os.path.join('src/static', photo.original_path.lstrip('/static/'))
                    if os.path.exists(original_path):
                        os.remove(original_path)
            except Exception as e:
                print(f"Error deleting photo file: {str(e)}")
            
            # Check if this was the primary photo
            was_primary = photo.is_primary
            
            # Delete from database
            db.session.delete(photo)
            
            # If this was the primary photo, set a new one
            if was_primary:
                next_photo = VehiclePhoto.query.filter_by(vehicle_id=photo.vehicle_id).first()
                if next_photo:
                    next_photo.is_primary = True
            
            db.session.commit()
            return jsonify({'success': True})
        else:
            return jsonify({'success': False, 'message': 'Photo not found'})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)})

# Reorder photos
@admin_bp.route('/inventory/photos/reorder', methods=['POST'])
@login_required
def reorder_photos():
    order_data = request.json
    
    if not order_data:
        return jsonify({'success': False, 'message': 'Missing order data'})
    
    try:
        for item in order_data:
            photo_id = item.get('id')
            order = item.get('order')
            
            if photo_id and order is not None:
                photo = VehiclePhoto.query.get(photo_id)
                if photo:
                    photo.order = order
        
        db.session.commit()
        return jsonify({'success': True})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)})

# Inquiries management
@admin_bp.route('/inquiries')
@login_required
def inquiries():
    # Get filter parameters
    status = request.args.get('status', 'all')
    
    # Base query
    query = Inquiry.query
    
    # Apply filters
    if status != 'all':
        query = query.filter_by(status=status)
    
    # Pagination
    page = request.args.get('page', 1, type=int)
    per_page = 10
    inquiries = query.order_by(Inquiry.created_at.desc()).paginate(page=page, per_page=per_page)
    
    return render_template('admin/inquiries.html', 
                          inquiries=inquiries,
                          current_status=status)

# Update inquiry status
@admin_bp.route('/inquiries/update-status', methods=['POST'])
@login_required
def update_inquiry_status():
    inquiry_id = request.form.get('inquiry_id')
    status = request.form.get('status')
    
    if not inquiry_id or not status:
        flash('Missing required parameters', 'danger')
        return redirect(url_for('admin.inquiries'))
    
    try:
        inquiry = Inquiry.query.get(inquiry_id)
        if inquiry:
            inquiry.status = status
            db.session.commit()
            flash('Inquiry status updated successfully!', 'success')
        else:
            flash('Inquiry not found', 'danger')
            
    except Exception as e:
        db.session.rollback()
        flash(f'Error updating inquiry: {str(e)}', 'danger')
    
    return redirect(url_for('admin.inquiries'))

# Delete inquiry
@admin_bp.route('/inquiries/delete/<int:inquiry_id>', methods=['POST'])
@login_required
def delete_inquiry(inquiry_id):
    try:
        inquiry = Inquiry.query.get_or_404(inquiry_id)
        db.session.delete(inquiry)
        db.session.commit()
        flash('Inquiry deleted successfully!', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Error deleting inquiry: {str(e)}', 'danger')
    
    return redirect(url_for('admin.inquiries'))

# Trade-ins management
@admin_bp.route('/trade-ins')
@login_required
def trade_ins():
    # Get filter parameters
    status = request.args.get('status', 'all')
    
    # Base query
    query = TradeIn.query
    
    # Apply filters
    if status != 'all':
        query = query.filter_by(status=status)
    
    # Pagination
    page = request.args.get('page', 1, type=int)
    per_page = 10
    trade_ins = query.order_by(TradeIn.created_at.desc()).paginate(page=page, per_page=per_page)
    
    return render_template('admin/trade_ins.html', 
                          trade_ins=trade_ins,
                          current_status=status)

# Update trade-in status
@admin_bp.route('/trade-ins/update-status', methods=['POST'])
@login_required
def update_trade_in_status():
    trade_in_id = request.form.get('trade_in_id')
    status = request.form.get('status')
    
    if not trade_in_id or not status:
        flash('Missing required parameters', 'danger')
        return redirect(url_for('admin.trade_ins'))
    
    try:
        trade_in = TradeIn.query.get(trade_in_id)
        if trade_in:
            trade_in.status = status
            db.session.commit()
            flash('Trade-in status updated successfully!', 'success')
        else:
            flash('Trade-in not found', 'danger')
            
    except Exception as e:
        db.session.rollback()
        flash(f'Error updating trade-in: {str(e)}', 'danger')
    
    return redirect(url_for('admin.trade_ins'))

# Delete trade-in
@admin_bp.route('/trade-ins/delete/<int:trade_in_id>', methods=['POST'])
@login_required
def delete_trade_in(trade_in_id):
    try:
        trade_in = TradeIn.query.get_or_404(trade_in_id)
        db.session.delete(trade_in)
        db.session.commit()
        flash('Trade-in deleted successfully!', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Error deleting trade-in: {str(e)}', 'danger')
    
    return redirect(url_for('admin.trade_ins'))

# Background images management
@admin_bp.route('/backgrounds')
@login_required
def backgrounds():
    backgrounds = BackgroundImage.query.all()
    return render_template('admin/backgrounds.html', backgrounds=backgrounds)

# Add background image
@admin_bp.route('/backgrounds/add', methods=['POST'])
@login_required
def add_background():
    try:
        name = request.form.get('name')
        category = request.form.get('category')
        
        if 'image' not in request.files:
            flash('No file selected', 'danger')
            return redirect(url_for('admin.backgrounds'))
        
        file = request.files['image']
        
        if file.filename == '':
            flash('No file selected', 'danger')
            return redirect(url_for('admin.backgrounds'))
        
        file_path = save_uploaded_file(file, subfolder='backgrounds')
        
        if file_path:
            new_background = BackgroundImage(
                name=name,
                file_path=file_path,
                category=category
            )
            
            db.session.add(new_background)
            db.session.commit()
            
            flash('Background image added successfully!', 'success')
        else:
            flash('Error saving file', 'danger')
            
    except Exception as e:
        db.session.rollback()
        flash(f'Error adding background image: {str(e)}', 'danger')
    
    return redirect(url_for('admin.backgrounds'))

# Delete background image
@admin_bp.route('/backgrounds/delete/<int:background_id>', methods=['POST'])
@login_required
def delete_background(background_id):
    try:
        background = BackgroundImage.query.get_or_404(background_id)
        
        # Delete file from filesystem
        try:
            file_path = os.path.join('src/static', background.file_path.lstrip('/static/'))
            if os.path.exists(file_path):
                os.remove(file_path)
        except Exception as e:
            print(f"Error deleting background file: {str(e)}")
        
        # Delete from database
        db.session.delete(background)
        db.session.commit()
        
        flash('Background image deleted successfully!', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Error deleting background image: {str(e)}', 'danger')
    
    return redirect(url_for('admin.backgrounds'))

# Toggle background active status
@admin_bp.route('/backgrounds/toggle-status/<int:background_id>', methods=['POST'])
@login_required
def toggle_background_status(background_id):
    try:
        background = BackgroundImage.query.get_or_404(background_id)
        background.is_active = not background.is_active
        db.session.commit()
        
        status = 'activated' if background.is_active else 'deactivated'
        flash(f'Background image {status} successfully!', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Error updating background status: {str(e)}', 'danger')
    
    return redirect(url_for('admin.backgrounds'))

# Site settings
@admin_bp.route('/settings', methods=['GET', 'POST'])
@login_required
def settings():
    if request.method == 'POST':
        try:
            # Process form data
            for key, value in request.form.items():
                if key.startswith('setting_'):
                    setting_name = key.replace('setting_', '')
                    
                    # Find or create setting
                    setting = SiteSettings.query.filter_by(setting_name=setting_name).first()
                    
                    if setting:
                        setting.setting_value = value
                    else:
                        new_setting = SiteSettings(
                            setting_name=setting_name,
                            setting_value=value
                        )
                        db.session.add(new_setting)
            
            db.session.commit()
            flash('Settings updated successfully!', 'success')
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error updating settings: {str(e)}', 'danger')
    
    # Get all settings
    settings = SiteSettings.query.all()
    
    # Convert to dictionary for easier access in template
    settings_dict = {}
    for setting in settings:
        settings_dict[setting.setting_name] = setting.setting_value
    
    return render_template('admin/settings.html', settings=settings_dict)

# User management
@admin_bp.route('/users')
@login_required
def users():
    # Only allow admin users to access this page
    if session.get('role') != 'admin':
        flash('You do not have permission to access this page', 'danger')
        return redirect(url_for('admin.dashboard'))
    
    users = User.query.all()
    return render_template('admin/users.html', users=users)

# Add user
@admin_bp.route('/users/add', methods=['GET', 'POST'])
@login_required
def add_user():
    # Only allow admin users to access this page
    if session.get('role') != 'admin':
        flash('You do not have permission to access this page', 'danger')
        return redirect(url_for('admin.dashboard'))
    
    if request.method == 'POST':
        try:
            username = request.form.get('username')
            email = request.form.get('email')
            password = request.form.get('password')
            first_name = request.form.get('first_name')
            last_name = request.form.get('last_name')
            role = request.form.get('role')
            
            # Validate required fields
            if not all([username, email, password]):
                flash('Please fill in all required fields', 'danger')
                return redirect(url_for('admin.add_user'))
            
            # Check if username or email already exists
            if User.query.filter_by(username=username).first():
                flash('Username already exists', 'danger')
                return redirect(url_for('admin.add_user'))
            
            if User.query.filter_by(email=email).first():
                flash('Email already exists', 'danger')
                return redirect(url_for('admin.add_user'))
            
            # Create new user
            new_user = User(
                username=username,
                email=email,
                password_hash=generate_password_hash(password),
                first_name=first_name,
                last_name=last_name,
                role=role
            )
            
            db.session.add(new_user)
            db.session.commit()
            
            flash(f'User {username} added successfully!', 'success')
            return redirect(url_for('admin.users'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error adding user: {str(e)}', 'danger')
    
    return render_template('admin/add_user.html')

# Edit user
@admin_bp.route('/users/edit/<int:user_id>', methods=['GET', 'POST'])
@login_required
def edit_user(user_id):
    # Only allow admin users to access this page
    if session.get('role') != 'admin':
        flash('You do not have permission to access this page', 'danger')
        return redirect(url_for('admin.dashboard'))
    
    user = User.query.get_or_404(user_id)
    
    if request.method == 'POST':
        try:
            user.username = request.form.get('username')
            user.email = request.form.get('email')
            user.first_name = request.form.get('first_name')
            user.last_name = request.form.get('last_name')
            user.role = request.form.get('role')
            user.is_active = 'is_active' in request.form
            
            # Update password if provided
            password = request.form.get('password')
            if password:
                user.password_hash = generate_password_hash(password)
            
            db.session.commit()
            
            flash(f'User {user.username} updated successfully!', 'success')
            return redirect(url_for('admin.users'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error updating user: {str(e)}', 'danger')
    
    return render_template('admin/edit_user.html', user=user)

# Delete user
@admin_bp.route('/users/delete/<int:user_id>', methods=['POST'])
@login_required
def delete_user(user_id):
    # Only allow admin users to access this page
    if session.get('role') != 'admin':
        flash('You do not have permission to access this page', 'danger')
        return redirect(url_for('admin.dashboard'))
    
    # Prevent deleting yourself
    if user_id == session.get('user_id'):
        flash('You cannot delete your own account', 'danger')
        return redirect(url_for('admin.users'))
    
    try:
        user = User.query.get_or_404(user_id)
        db.session.delete(user)
        db.session.commit()
        
        flash(f'User {user.username} deleted successfully!', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Error deleting user: {str(e)}', 'danger')
    
    return redirect(url_for('admin.users'))

# Profile management
@admin_bp.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    user = User.query.get(session.get('user_id'))
    
    if request.method == 'POST':
        try:
            user.first_name = request.form.get('first_name')
            user.last_name = request.form.get('last_name')
            user.email = request.form.get('email')
            
            # Update password if provided
            current_password = request.form.get('current_password')
            new_password = request.form.get('new_password')
            confirm_password = request.form.get('confirm_password')
            
            if current_password and new_password and confirm_password:
                if not check_password_hash(user.password_hash, current_password):
                    flash('Current password is incorrect', 'danger')
                    return redirect(url_for('admin.profile'))
                
                if new_password != confirm_password:
                    flash('New passwords do not match', 'danger')
                    return redirect(url_for('admin.profile'))
                
                user.password_hash = generate_password_hash(new_password)
            
            db.session.commit()
            
            flash('Profile updated successfully!', 'success')
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error updating profile: {str(e)}', 'danger')
    
    return render_template('admin/profile.html', user=user)
