from flask import Blueprint, render_template, request, jsonify, current_app
from src.models.models import VehiclePhoto, BackgroundImage
from src.main import db, save_uploaded_file
import os
import cv2
import numpy as np
from PIL import Image, ImageEnhance, ImageFilter
import uuid
import base64
import io
import json

api_bp = Blueprint('api', __name__)

# AI Photo Editing API
@api_bp.route('/photo/edit', methods=['POST'])
def edit_photo():
    try:
        # Get parameters
        photo_id = request.form.get('photo_id')
        edit_type = request.form.get('edit_type')  # background, enhance, etc.
        
        if not photo_id or not edit_type:
            return jsonify({'success': False, 'message': 'Missing required parameters'})
        
        # Get photo from database
        photo = VehiclePhoto.query.get(photo_id)
        
        if not photo:
            return jsonify({'success': False, 'message': 'Photo not found'})
        
        # Get original image path
        original_path = photo.original_path or photo.file_path
        file_path = os.path.join(current_app.root_path, 'static', original_path.lstrip('/static/'))
        
        if not os.path.exists(file_path):
            return jsonify({'success': False, 'message': 'Image file not found'})
        
        # Process based on edit type
        if edit_type == 'background':
            background_id = request.form.get('background_id')
            
            if not background_id:
                return jsonify({'success': False, 'message': 'Missing background ID'})
            
            # Get background image
            background = BackgroundImage.query.get(background_id)
            
            if not background:
                return jsonify({'success': False, 'message': 'Background not found'})
            
            background_path = os.path.join(current_app.root_path, 'static', background.file_path.lstrip('/static/'))
            
            if not os.path.exists(background_path):
                return jsonify({'success': False, 'message': 'Background file not found'})
            
            # Replace background
            result_path = replace_background(file_path, background_path)
            
        elif edit_type == 'enhance':
            # Get enhancement parameters
            brightness = float(request.form.get('brightness', 1.0))
            contrast = float(request.form.get('contrast', 1.0))
            saturation = float(request.form.get('saturation', 1.0))
            sharpness = float(request.form.get('sharpness', 1.0))
            
            # Enhance image
            result_path = enhance_image(file_path, brightness, contrast, saturation, sharpness)
            
        else:
            return jsonify({'success': False, 'message': 'Invalid edit type'})
        
        if not result_path:
            return jsonify({'success': False, 'message': 'Error processing image'})
        
        # Update photo in database
        web_path = result_path.replace(current_app.root_path, '').replace('\\', '/')
        if not web_path.startswith('/'):
            web_path = '/' + web_path
            
        photo.file_path = web_path
        db.session.commit()
        
        return jsonify({
            'success': True, 
            'file_path': web_path,
            'photo_id': photo.id
        })
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

# Background replacement function
def replace_background(image_path, background_path):
    try:
        # Load image
        img = cv2.imread(image_path)
        background = cv2.imread(background_path)
        
        # Resize background to match image dimensions
        background = cv2.resize(background, (img.shape[1], img.shape[0]))
        
        # For a real implementation, we would use a pre-trained segmentation model
        # to create a mask for the vehicle. For this prototype, we'll use a simplified approach.
        
        # Convert to grayscale
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        # Apply threshold
        _, thresh = cv2.threshold(gray, 200, 255, cv2.THRESH_BINARY_INV)
        
        # Find contours
        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        # Create mask
        mask = np.zeros_like(gray)
        cv2.drawContours(mask, contours, -1, 255, -1)
        
        # Apply Gaussian blur to smooth the mask
        mask = cv2.GaussianBlur(mask, (21, 21), 0)
        
        # Normalize mask to range 0-1
        mask = mask / 255.0
        
        # Expand mask to 3 channels
        mask_3channel = np.stack([mask, mask, mask], axis=2)
        
        # Blend images
        result = img * mask_3channel + background * (1 - mask_3channel)
        
        # Save result
        result_filename = f"edited_{uuid.uuid4().hex}.jpg"
        result_path = os.path.join(current_app.root_path, 'static', 'uploads', 'vehicles', result_filename)
        cv2.imwrite(result_path, result)
        
        return result_path
        
    except Exception as e:
        print(f"Error in replace_background: {str(e)}")
        return None

# Image enhancement function
def enhance_image(image_path, brightness=1.0, contrast=1.0, saturation=1.0, sharpness=1.0):
    try:
        # Open image with PIL
        img = Image.open(image_path)
        
        # Apply enhancements
        if brightness != 1.0:
            enhancer = ImageEnhance.Brightness(img)
            img = enhancer.enhance(brightness)
            
        if contrast != 1.0:
            enhancer = ImageEnhance.Contrast(img)
            img = enhancer.enhance(contrast)
            
        if saturation != 1.0:
            enhancer = ImageEnhance.Color(img)
            img = enhancer.enhance(saturation)
            
        if sharpness != 1.0:
            enhancer = ImageEnhance.Sharpness(img)
            img = enhancer.enhance(sharpness)
        
        # Save result
        result_filename = f"edited_{uuid.uuid4().hex}.jpg"
        result_path = os.path.join(current_app.root_path, 'static', 'uploads', 'vehicles', result_filename)
        img.save(result_path, "JPEG", quality=95)
        
        return result_path
        
    except Exception as e:
        print(f"Error in enhance_image: {str(e)}")
        return None

# Process image from base64 data
@api_bp.route('/photo/process-base64', methods=['POST'])
def process_base64_image():
    try:
        data = request.json
        
        if not data or 'image_data' not in data:
            return jsonify({'success': False, 'message': 'Missing image data'})
        
        # Get image data
        image_data = data['image_data']
        
        # Remove data URL prefix if present
        if image_data.startswith('data:image'):
            image_data = image_data.split(',')[1]
        
        # Decode base64
        image_bytes = base64.b64decode(image_data)
        
        # Create PIL Image
        img = Image.open(io.BytesIO(image_bytes))
        
        # Save image
        result_filename = f"uploaded_{uuid.uuid4().hex}.jpg"
        result_path = os.path.join(current_app.root_path, 'static', 'uploads', 'vehicles', result_filename)
        img.save(result_path, "JPEG", quality=95)
        
        # Create web path
        web_path = os.path.join('static', 'uploads', 'vehicles', result_filename)
        
        return jsonify({
            'success': True,
            'file_path': '/' + web_path.replace('\\', '/')
        })
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

# Get available backgrounds
@api_bp.route('/backgrounds', methods=['GET'])
def get_backgrounds():
    try:
        category = request.args.get('category', 'all')
        
        query = BackgroundImage.query.filter_by(is_active=True)
        
        if category != 'all':
            query = query.filter_by(category=category)
        
        backgrounds = query.all()
        
        result = []
        for bg in backgrounds:
            result.append({
                'id': bg.id,
                'name': bg.name,
                'file_path': bg.file_path,
                'category': bg.category
            })
        
        return jsonify({
            'success': True,
            'backgrounds': result
        })
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

# Vehicle API routes for frontend
@api_bp.route('/vehicles', methods=['GET'])
def get_vehicles():
    try:
        # Get filter parameters
        make = request.args.get('make', 'all')
        model = request.args.get('model', 'all')
        price_range = request.args.get('price', 'all')
        body_type = request.args.get('body_type', 'all')
        year = request.args.get('year', 'all')
        mileage = request.args.get('mileage', 'all')
        
        # Import here to avoid circular imports
        from src.models.models import Vehicle
        
        # Base query - only available vehicles
        query = Vehicle.query.filter_by(status='available')
        
        # Apply filters
        if make != 'all':
            query = query.filter_by(make=make)
            
        if model != 'all':
            query = query.filter_by(model=model)
            
        if body_type != 'all':
            query = query.filter_by(body_type=body_type)
            
        if year != 'all':
            query = query.filter_by(year=year)
            
        if price_range != 'all':
            price_min, price_max = map(int, price_range.split('-'))
            query = query.filter(Vehicle.price >= price_min, Vehicle.price <= price_max)
            
        if mileage != 'all':
            mileage_min, mileage_max = map(int, mileage.split('-'))
            query = query.filter(Vehicle.mileage >= mileage_min, Vehicle.mileage <= mileage_max)
        
        # Get results
        vehicles = query.all()
        
        # Format results
        result = []
        for vehicle in vehicles:
            result.append({
                'id': vehicle.id,
                'title': vehicle.title,
                'year': vehicle.year,
                'make': vehicle.make,
                'model': vehicle.model,
                'trim': vehicle.trim,
                'price': float(vehicle.price),
                'mileage': vehicle.mileage,
                'engine': vehicle.engine,
                'transmission': vehicle.transmission,
                'drivetrain': vehicle.drivetrain,
                'exterior_color': vehicle.exterior_color,
                'interior_color': vehicle.interior_color,
                'body_type': vehicle.body_type,
                'stock_number': vehicle.stock_number,
                'vin': vehicle.vin,
                'primary_photo': vehicle.primary_photo
            })
        
        return jsonify({
            'success': True,
            'vehicles': result,
            'count': len(result)
        })
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

# Get vehicle details
@api_bp.route('/vehicles/<int:vehicle_id>', methods=['GET'])
def get_vehicle_details(vehicle_id):
    try:
        # Import here to avoid circular imports
        from src.models.models import Vehicle
        
        vehicle = Vehicle.query.get(vehicle_id)
        
        if not vehicle:
            return jsonify({'success': False, 'message': 'Vehicle not found'})
        
        # Get all photos
        photos = []
        for photo in vehicle.photos:
            photos.append({
                'id': photo.id,
                'file_path': photo.file_path,
                'is_primary': photo.is_primary
            })
        
        # Format result
        result = {
            'id': vehicle.id,
            'title': vehicle.title,
            'year': vehicle.year,
            'make': vehicle.make,
            'model': vehicle.model,
            'trim': vehicle.trim,
            'price': float(vehicle.price),
            'mileage': vehicle.mileage,
            'engine': vehicle.engine,
            'transmission': vehicle.transmission,
            'drivetrain': vehicle.drivetrain,
            'exterior_color': vehicle.exterior_color,
            'interior_color': vehicle.interior_color,
            'body_type': vehicle.body_type,
            'fuel_type': vehicle.fuel_type,
            'mpg_city': vehicle.mpg_city,
            'mpg_highway': vehicle.mpg_highway,
            'stock_number': vehicle.stock_number,
            'vin': vehicle.vin,
            'description': vehicle.description,
            'features': vehicle.features,
            'photos': photos,
            'primary_photo': vehicle.primary_photo
        }
        
        return jsonify({
            'success': True,
            'vehicle': result
        })
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

# Submit inquiry
@api_bp.route('/inquiries/submit', methods=['POST'])
def submit_inquiry():
    try:
        # Get form data
        vehicle_id = request.form.get('vehicle_id')
        name = request.form.get('name')
        email = request.form.get('email')
        phone = request.form.get('phone')
        message = request.form.get('message')
        
        # Validate required fields
        if not all([name, email, message]):
            return jsonify({'success': False, 'message': 'Please fill in all required fields'})
        
        # Import here to avoid circular imports
        from src.models.models import Inquiry
        
        # Create new inquiry
        new_inquiry = Inquiry(
            vehicle_id=vehicle_id if vehicle_id else None,
            name=name,
            email=email,
            phone=phone,
            message=message
        )
        
        db.session.add(new_inquiry)
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Inquiry submitted successfully!'})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)})

# Submit trade-in
@api_bp.route('/trade-ins/submit', methods=['POST'])
def submit_trade_in():
    try:
        # Get form data
        name = request.form.get('name')
        email = request.form.get('email')
        phone = request.form.get('phone')
        year = request.form.get('year')
        make = request.form.get('make')
        model = request.form.get('model')
        trim = request.form.get('trim')
        mileage = request.form.get('mileage')
        condition = request.form.get('condition')
        vin = request.form.get('vin')
        comments = request.form.get('comments')
        
        # Validate required fields
        if not all([name, email, year, make, model, mileage]):
            return jsonify({'success': False, 'message': 'Please fill in all required fields'})
        
        # Import here to avoid circular imports
        from src.models.models import TradeIn
        
        # Create new trade-in
        new_trade_in = TradeIn(
            name=name,
            email=email,
            phone=phone,
            year=year,
            make=make,
            model=model,
            trim=trim,
            mileage=mileage,
            condition=condition,
            vin=vin,
            comments=comments
        )
        
        db.session.add(new_trade_in)
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Trade-in request submitted successfully!'})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)})

# Get site settings
@api_bp.route('/settings', methods=['GET'])
def get_settings():
    try:
        # Import here to avoid circular imports
        from src.models.models import SiteSettings
        
        # Get public settings
        settings = SiteSettings.query.filter_by(is_public=True).all()
        
        # Format result
        result = {}
        for setting in settings:
            # Convert value based on type
            if setting.setting_type == 'number':
                result[setting.setting_name] = float(setting.setting_value)
            elif setting.setting_type == 'boolean':
                result[setting.setting_name] = setting.setting_value.lower() == 'true'
            elif setting.setting_type == 'json':
                result[setting.setting_name] = json.loads(setting.setting_value)
            else:
                result[setting.setting_name] = setting.setting_value
        
        return jsonify({
            'success': True,
            'settings': result
        })
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})
