from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
import os

# Create blueprint
main_bp = Blueprint('main', __name__)

# Home page
@main_bp.route('/')
def home():
    return render_template('index.html')

# Inventory page
@main_bp.route('/inventory')
def inventory():
    return render_template('inventory.html')

# Vehicle detail page
@main_bp.route('/inventory/<int:vehicle_id>')
def vehicle_detail(vehicle_id):
    return render_template('vehicle_detail.html')

# Finance page
@main_bp.route('/finance')
def finance():
    return render_template('finance.html')

# Sell/Trade page
@main_bp.route('/sell-trade')
def sell_trade():
    return render_template('sell_trade.html')

# Advantage Package page
@main_bp.route('/advantage-package')
def advantage_package():
    return render_template('advantage_package.html')

# Why Buy From Us page
@main_bp.route('/why-buy-from-us')
def why_buy_from_us():
    return render_template('why_buy_from_us.html')

# Contact Us page
@main_bp.route('/contact')
def contact():
    return render_template('contact.html')

# Submit contact form
@main_bp.route('/contact/submit', methods=['POST'])
def submit_contact():
    return redirect(url_for('main.contact'))

# Submit trade-in form
@main_bp.route('/sell-trade/submit', methods=['POST'])
def submit_trade_in():
    return redirect(url_for('main.sell_trade'))

# Submit vehicle inquiry
@main_bp.route('/inventory/inquiry', methods=['POST'])
def submit_vehicle_inquiry():
    return redirect(url_for('main.inventory'))

# Privacy Policy page
@main_bp.route('/privacy-policy')
def privacy_policy():
    return render_template('privacy_policy.html')

# Terms of Service page
@main_bp.route('/terms-of-service')
def terms_of_service():
    return render_template('terms_of_service.html')
