from src.main import db
from datetime import datetime
from sqlalchemy.orm import relationship

class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    first_name = db.Column(db.String(50))
    last_name = db.Column(db.String(50))
    role = db.Column(db.String(20), default='admin')  # admin, staff
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    
    def __repr__(self):
        return f'<User {self.username}>'

class Vehicle(db.Model):
    __tablename__ = 'vehicles'
    
    id = db.Column(db.Integer, primary_key=True)
    stock_number = db.Column(db.String(20), unique=True, nullable=False)
    vin = db.Column(db.String(17), unique=True, nullable=False)
    year = db.Column(db.Integer, nullable=False)
    make = db.Column(db.String(50), nullable=False)
    model = db.Column(db.String(50), nullable=False)
    trim = db.Column(db.String(50))
    body_type = db.Column(db.String(30))
    exterior_color = db.Column(db.String(30))
    interior_color = db.Column(db.String(30))
    mileage = db.Column(db.Integer, nullable=False)
    price = db.Column(db.Numeric(10, 2), nullable=False)
    engine = db.Column(db.String(50))
    transmission = db.Column(db.String(30))
    drivetrain = db.Column(db.String(20))
    fuel_type = db.Column(db.String(20))
    mpg_city = db.Column(db.Integer)
    mpg_highway = db.Column(db.Integer)
    description = db.Column(db.Text)
    features = db.Column(db.Text)
    status = db.Column(db.String(20), default='available')  # available, pending, sold
    is_featured = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    photos = relationship('VehiclePhoto', back_populates='vehicle', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Vehicle {self.year} {self.make} {self.model}>'
    
    @property
    def primary_photo(self):
        primary = next((photo for photo in self.photos if photo.is_primary), None)
        if primary:
            return primary.file_path
        elif self.photos:
            return self.photos[0].file_path
        else:
            return '/static/images/no-image.jpg'
    
    @property
    def title(self):
        return f"{self.year} {self.make} {self.model} {self.trim or ''}".strip()

class VehiclePhoto(db.Model):
    __tablename__ = 'vehicle_photos'
    
    id = db.Column(db.Integer, primary_key=True)
    vehicle_id = db.Column(db.Integer, db.ForeignKey('vehicles.id'), nullable=False)
    file_path = db.Column(db.String(255), nullable=False)
    file_name = db.Column(db.String(255), nullable=False)
    is_primary = db.Column(db.Boolean, default=False)
    original_path = db.Column(db.String(255))  # Path to original unedited image
    order = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    vehicle = relationship('Vehicle', back_populates='photos')
    
    def __repr__(self):
        return f'<VehiclePhoto {self.file_name}>'

class Inquiry(db.Model):
    __tablename__ = 'inquiries'
    
    id = db.Column(db.Integer, primary_key=True)
    vehicle_id = db.Column(db.Integer, db.ForeignKey('vehicles.id'))
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20))
    message = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), default='new')  # new, contacted, closed
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    vehicle = relationship('Vehicle')
    
    def __repr__(self):
        return f'<Inquiry {self.name}>'

class TradeIn(db.Model):
    __tablename__ = 'trade_ins'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20))
    year = db.Column(db.Integer, nullable=False)
    make = db.Column(db.String(50), nullable=False)
    model = db.Column(db.String(50), nullable=False)
    trim = db.Column(db.String(50))
    mileage = db.Column(db.Integer, nullable=False)
    condition = db.Column(db.String(20))
    vin = db.Column(db.String(17))
    comments = db.Column(db.Text)
    status = db.Column(db.String(20), default='new')  # new, evaluated, completed, declined
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<TradeIn {self.year} {self.make} {self.model}>'

class BackgroundImage(db.Model):
    __tablename__ = 'background_images'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    file_path = db.Column(db.String(255), nullable=False)
    category = db.Column(db.String(50), default='general')  # general, showroom, outdoor, etc.
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<BackgroundImage {self.name}>'

class SiteSettings(db.Model):
    __tablename__ = 'site_settings'
    
    id = db.Column(db.Integer, primary_key=True)
    setting_name = db.Column(db.String(50), unique=True, nullable=False)
    setting_value = db.Column(db.Text)
    setting_type = db.Column(db.String(20), default='text')  # text, number, boolean, json
    is_public = db.Column(db.Boolean, default=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<SiteSettings {self.setting_name}>'
