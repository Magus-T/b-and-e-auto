// B&E Auto - Main JavaScript File

document.addEventListener('DOMContentLoaded', function() {
    // Mobile Menu Toggle
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const mainNav = document.querySelector('.main-nav');
    
    if (mobileMenuToggle && mainNav) {
        mobileMenuToggle.addEventListener('click', function() {
            mainNav.classList.toggle('active');
        });
    }
    
    // Vehicle Image Slider (for vehicle detail page)
    initializeVehicleSlider();
    
    // Search Form Reset Button
    const resetFilterBtn = document.querySelector('.reset-filter-btn');
    if (resetFilterBtn) {
        resetFilterBtn.addEventListener('click', function() {
            const searchForm = document.querySelector('.search-form');
            if (searchForm) {
                const selects = searchForm.querySelectorAll('select');
                const inputs = searchForm.querySelectorAll('input:not([type="submit"])');
                
                selects.forEach(select => {
                    select.selectedIndex = 0;
                });
                
                inputs.forEach(input => {
                    input.value = '';
                });
            }
        });
    }
    
    // Testimonial Slider
    initializeTestimonialSlider();
    
    // Admin Dashboard - Photo Upload
    initializePhotoUpload();
    
    // Admin Dashboard - AI Photo Editor
    initializePhotoEditor();
});

// Vehicle Image Slider
function initializeVehicleSlider() {
    const mainImage = document.querySelector('.vehicle-main-image img');
    const thumbnails = document.querySelectorAll('.vehicle-thumbnail');
    
    if (mainImage && thumbnails.length > 0) {
        thumbnails.forEach(thumbnail => {
            thumbnail.addEventListener('click', function() {
                // Update main image
                const imgSrc = this.getAttribute('data-src');
                mainImage.src = imgSrc;
                
                // Update active state
                thumbnails.forEach(thumb => thumb.classList.remove('active'));
                this.classList.add('active');
            });
        });
    }
}

// Testimonial Slider
function initializeTestimonialSlider() {
    const testimonials = document.querySelectorAll('.testimonial');
    const prevBtn = document.querySelector('.testimonial-prev');
    const nextBtn = document.querySelector('.testimonial-next');
    
    if (testimonials.length > 0 && prevBtn && nextBtn) {
        let currentIndex = 0;
        
        // Show only the current testimonial
        function updateTestimonials() {
            testimonials.forEach((testimonial, index) => {
                if (index === currentIndex) {
                    testimonial.style.display = 'block';
                } else {
                    testimonial.style.display = 'none';
                }
            });
        }
        
        // Initialize
        updateTestimonials();
        
        // Next button
        nextBtn.addEventListener('click', function() {
            currentIndex = (currentIndex + 1) % testimonials.length;
            updateTestimonials();
        });
        
        // Previous button
        prevBtn.addEventListener('click', function() {
            currentIndex = (currentIndex - 1 + testimonials.length) % testimonials.length;
            updateTestimonials();
        });
        
        // Auto-rotate testimonials
        setInterval(function() {
            currentIndex = (currentIndex + 1) % testimonials.length;
            updateTestimonials();
        }, 5000);
    }
}

// Admin Dashboard - Photo Upload
function initializePhotoUpload() {
    const photoUploadArea = document.querySelector('.photo-upload-area');
    const photoUploadInput = document.querySelector('.photo-upload-input');
    const photoGallery = document.querySelector('.photo-gallery');
    
    if (photoUploadArea && photoUploadInput) {
        // Drag and drop functionality
        photoUploadArea.addEventListener('dragover', function(e) {
            e.preventDefault();
            photoUploadArea.classList.add('active');
        });
        
        photoUploadArea.addEventListener('dragleave', function() {
            photoUploadArea.classList.remove('active');
        });
        
        photoUploadArea.addEventListener('drop', function(e) {
            e.preventDefault();
            photoUploadArea.classList.remove('active');
            
            if (e.dataTransfer.files.length) {
                photoUploadInput.files = e.dataTransfer.files;
                handleFiles(e.dataTransfer.files);
            }
        });
        
        // Click to upload
        photoUploadArea.addEventListener('click', function() {
            photoUploadInput.click();
        });
        
        photoUploadInput.addEventListener('change', function() {
            if (this.files.length) {
                handleFiles(this.files);
            }
        });
        
        // Handle uploaded files
        function handleFiles(files) {
            if (!photoGallery) return;
            
            Array.from(files).forEach(file => {
                if (!file.type.match('image.*')) return;
                
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    const photoItem = document.createElement('div');
                    photoItem.className = 'photo-item';
                    
                    photoItem.innerHTML = `
                        <img src="${e.target.result}" alt="Vehicle Photo">
                        <div class="photo-item-overlay">
                            <div class="photo-item-action" title="Set as Primary">
                                <i class="fas fa-star"></i>
                            </div>
                            <div class="photo-item-action" title="Edit Photo">
                                <i class="fas fa-edit"></i>
                            </div>
                            <div class="photo-item-action" title="Delete Photo">
                                <i class="fas fa-trash"></i>
                            </div>
                        </div>
                    `;
                    
                    photoGallery.appendChild(photoItem);
                    
                    // Set as primary functionality
                    const setPrimaryBtn = photoItem.querySelector('.photo-item-action[title="Set as Primary"]');
                    if (setPrimaryBtn) {
                        setPrimaryBtn.addEventListener('click', function() {
                            const allPhotoItems = photoGallery.querySelectorAll('.photo-item');
                            allPhotoItems.forEach(item => {
                                const primaryBadge = item.querySelector('.photo-item-primary');
                                if (primaryBadge) {
                                    primaryBadge.remove();
                                }
                            });
                            
                            const primaryBadge = document.createElement('div');
                            primaryBadge.className = 'photo-item-primary';
                            primaryBadge.textContent = 'Primary';
                            photoItem.appendChild(primaryBadge);
                        });
                    }
                    
                    // Edit photo functionality
                    const editBtn = photoItem.querySelector('.photo-item-action[title="Edit Photo"]');
                    if (editBtn) {
                        editBtn.addEventListener('click', function() {
                            // Open photo editor with this image
                            const photoEditor = document.querySelector('.photo-editor');
                            const photoEditorPreviewImg = document.querySelector('.photo-editor-preview img');
                            
                            if (photoEditor && photoEditorPreviewImg) {
                                photoEditor.style.display = 'flex';
                                photoEditorPreviewImg.src = e.target.result;
                            }
                        });
                    }
                    
                    // Delete photo functionality
                    const deleteBtn = photoItem.querySelector('.photo-item-action[title="Delete Photo"]');
                    if (deleteBtn) {
                        deleteBtn.addEventListener('click', function() {
                            photoItem.remove();
                        });
                    }
                };
                
                reader.readAsDataURL(file);
            });
        }
    }
}

// Admin Dashboard - AI Photo Editor
function initializePhotoEditor() {
    const photoEditor = document.querySelector('.photo-editor');
    const photoEditorPreviewImg = document.querySelector('.photo-editor-preview img');
    const backgroundItems = document.querySelectorAll('.photo-editor-background');
    const brightnessSlider = document.querySelector('#brightness-slider');
    const contrastSlider = document.querySelector('#contrast-slider');
    const saturationSlider = document.querySelector('#saturation-slider');
    const applyBtn = document.querySelector('#apply-edits-btn');
    const cancelBtn = document.querySelector('#cancel-edits-btn');
    
    if (photoEditor && photoEditorPreviewImg) {
        // Background selection
        if (backgroundItems.length > 0) {
            backgroundItems.forEach(item => {
                item.addEventListener('click', function() {
                    backgroundItems.forEach(bg => bg.classList.remove('active'));
                    this.classList.add('active');
                    
                    // In a real implementation, this would apply the background
                    // using image segmentation and compositing
                });
            });
        }
        
        // Image adjustment sliders
        if (brightnessSlider) {
            brightnessSlider.addEventListener('input', function() {
                // In a real implementation, this would adjust the image brightness
                photoEditorPreviewImg.style.filter = `brightness(${this.value}%)`;
            });
        }
        
        if (contrastSlider) {
            contrastSlider.addEventListener('input', function() {
                // In a real implementation, this would adjust the image contrast
                photoEditorPreviewImg.style.filter = `contrast(${this.value}%)`;
            });
        }
        
        if (saturationSlider) {
            saturationSlider.addEventListener('input', function() {
                // In a real implementation, this would adjust the image saturation
                photoEditorPreviewImg.style.filter = `saturate(${this.value}%)`;
            });
        }
        
        // Apply button
        if (applyBtn) {
            applyBtn.addEventListener('click', function() {
                // In a real implementation, this would apply all edits and save the image
                photoEditor.style.display = 'none';
            });
        }
        
        // Cancel button
        if (cancelBtn) {
            cancelBtn.addEventListener('click', function() {
                photoEditor.style.display = 'none';
            });
        }
    }
}

// Vehicle Filtering
function filterVehicles() {
    const make = document.querySelector('#make-filter').value;
    const model = document.querySelector('#model-filter').value;
    const priceRange = document.querySelector('#price-filter').value;
    const bodyType = document.querySelector('#body-type-filter').value;
    const year = document.querySelector('#year-filter').value;
    const mileage = document.querySelector('#mileage-filter').value;
    
    // In a real implementation, this would send an AJAX request to the server
    // or filter the vehicles on the client side
    
    console.log('Filtering vehicles with criteria:', {
        make,
        model,
        priceRange,
        bodyType,
        year,
        mileage
    });
}

// Finance Calculator
function calculateFinance() {
    const vehiclePrice = parseFloat(document.querySelector('#vehicle-price').value) || 0;
    const downPayment = parseFloat(document.querySelector('#down-payment').value) || 0;
    const interestRate = parseFloat(document.querySelector('#interest-rate').value) || 0;
    const loanTerm = parseInt(document.querySelector('#loan-term').value) || 0;
    
    if (vehiclePrice > 0 && loanTerm > 0) {
        const loanAmount = vehiclePrice - downPayment;
        const monthlyInterest = interestRate / 100 / 12;
        const months = loanTerm * 12;
        
        let monthlyPayment = 0;
        
        if (interestRate > 0) {
            monthlyPayment = loanAmount * monthlyInterest * Math.pow(1 + monthlyInterest, months) / (Math.pow(1 + monthlyInterest, months) - 1);
        } else {
            monthlyPayment = loanAmount / months;
        }
        
        const resultElement = document.querySelector('#finance-result');
        if (resultElement) {
            resultElement.textContent = `$${monthlyPayment.toFixed(2)} per month`;
        }
    }
}

// Admin Dashboard - Toggle Mobile Menu
function toggleAdminMenu() {
    const adminMenu = document.querySelector('.admin-menu');
    if (adminMenu) {
        adminMenu.classList.toggle('active');
    }
}
