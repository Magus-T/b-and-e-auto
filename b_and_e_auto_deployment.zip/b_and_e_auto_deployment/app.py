from flask import Flask, render_template, send_from_directory, url_for, redirect, request, flash, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import os
import sys
import uuid
from datetime import datetime

# Initialize Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(24)

# Configure database
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'sqlite:///beauto.db')
if app.config['SQLALCHEMY_DATABASE_URI'].startswith("postgres://"):
    app.config['SQLALCHEMY_DATABASE_URI'] = app.config['SQLALCHEMY_DATABASE_URI'].replace("postgres://", "postgresql://", 1)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize database
db = SQLAlchemy(app)

# Configure file uploads
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static/uploads')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload

# Ensure upload directory exists
os.makedirs(os.path.join(app.config['UPLOAD_FOLDER'], 'vehicles'), exist_ok=True)
os.makedirs(os.path.join(app.config['UPLOAD_FOLDER'], 'backgrounds'), exist_ok=True)

# Models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    first_name = db.Column(db.String(50))
    last_name = db.Column(db.String(50))
    role = db.Column(db.String(20), default='user')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Vehicle(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    stock_number = db.Column(db.String(20), unique=True)
    vin = db.Column(db.String(17))
    year = db.Column(db.Integer)
    make = db.Column(db.String(50))
    model = db.Column(db.String(50))
    trim = db.Column(db.String(50))
    body_type = db.Column(db.String(30))
    color = db.Column(db.String(30))
    interior_color = db.Column(db.String(30))
    mileage = db.Column(db.Integer)
    price = db.Column(db.Float)
    description = db.Column(db.Text)
    features = db.Column(db.Text)
    engine = db.Column(db.String(50))
    transmission = db.Column(db.String(30))
    drivetrain = db.Column(db.String(20))
    fuel_type = db.Column(db.String(20))
    mpg_city = db.Column(db.Float)
    mpg_highway = db.Column(db.Float)
    status = db.Column(db.String(20), default='available')
    is_featured = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    photos = db.relationship('VehiclePhoto', backref='vehicle', lazy=True, cascade="all, delete-orphan")
    inquiries = db.relationship('Inquiry', backref='vehicle', lazy=True)

class VehiclePhoto(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    vehicle_id = db.Column(db.Integer, db.ForeignKey('vehicle.id'), nullable=False)
    file_path = db.Column(db.String(255), nullable=False)
    is_primary = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Inquiry(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    vehicle_id = db.Column(db.Integer, db.ForeignKey('vehicle.id'))
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(20))
    message = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), default='new')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class TradeIn(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(20))
    year = db.Column(db.Integer, nullable=False)
    make = db.Column(db.String(50), nullable=False)
    model = db.Column(db.String(50), nullable=False)
    trim = db.Column(db.String(50))
    mileage = db.Column(db.Integer, nullable=False)
    condition = db.Column(db.String(20))
    vin = db.Column(db.String(17))
    comments = db.Column(db.Text)
    status = db.Column(db.String(20), default='new')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class BackgroundImage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    file_path = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class SiteSettings(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    setting_name = db.Column(db.String(100), unique=True, nullable=False)
    setting_value = db.Column(db.Text)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

# Routes
@app.route('/')
def home():
    # Get featured vehicles
    featured_vehicles = Vehicle.query.filter_by(is_featured=True, status='available').limit(4).all()
    
    # If not enough featured vehicles, get the most recent ones
    if len(featured_vehicles) < 4:
        additional_count = 4 - len(featured_vehicles)
        featured_ids = [v.id for v in featured_vehicles]
        additional_vehicles = Vehicle.query.filter(
            Vehicle.id.notin_(featured_ids) if featured_ids else True,
            Vehicle.status == 'available'
        ).order_by(Vehicle.created_at.desc()).limit(additional_count).all()
        
        featured_vehicles.extend(additional_vehicles)
    
    return render_template('index.html', featured_vehicles=featured_vehicles)

@app.route('/inventory')
def inventory():
    # Get filter parameters
    make = request.args.get('make', 'all')
    model = request.args.get('model', 'all')
    price_range = request.args.get('price', 'all')
    body_type = request.args.get('body_type', 'all')
    year = request.args.get('year', 'all')
    mileage = request.args.get('mileage', 'all')
    sort = request.args.get('sort', 'newest')
    
    # Base query - only available vehicles
    query = Vehicle.query.filter_by(status='available')
    
    # Apply filters
    if make != 'all':
        query = query.filter_by(make=make)
        
    if model != 'all':
        query = query.filter_by(model=model)
        
    if body_type != 'all':
        query = query.filter_by(body_type=body_type)
        
    if year != 'all':
        query = query.filter_by(year=year)
        
    if price_range != 'all':
        price_min, price_max = map(int, price_range.split('-'))
        query = query.filter(Vehicle.price >= price_min, Vehicle.price <= price_max)
        
    if mileage != 'all':
        mileage_min, mileage_max = map(int, mileage.split('-'))
        query = query.filter(Vehicle.mileage >= mileage_min, Vehicle.mileage <= mileage_max)
    
    # Apply sorting
    if sort == 'newest':
        query = query.order_by(Vehicle.created_at.desc())
    elif sort == 'oldest':
        query = query.order_by(Vehicle.created_at)
    elif sort == 'price_high':
        query = query.order_by(Vehicle.price.desc())
    elif sort == 'price_low':
        query = query.order_by(Vehicle.price)
    
    # Get distinct makes, models, years, and body types for filter dropdowns
    makes = db.session.query(Vehicle.make).filter(Vehicle.status == 'available').distinct().all()
    makes = [make[0] for make in makes if make[0]]
    
    models = db.session.query(Vehicle.model).filter(Vehicle.status == 'available').distinct().all()
    models = [model[0] for model in models if model[0]]
    
    years = db.session.query(Vehicle.year).filter(Vehicle.status == 'available').distinct().all()
    years = [year[0] for year in years if year[0]]
    years.sort(reverse=True)
    
    body_types = db.session.query(Vehicle.body_type).filter(Vehicle.status == 'available').distinct().all()
    body_types = [bt[0] for bt in body_types if bt[0]]
    
    # Pagination
    page = request.args.get('page', 1, type=int)
    per_page = 12
    vehicles = query.paginate(page=page, per_page=per_page)
    
    return render_template('inventory/index.html', 
                          vehicles=vehicles,
                          makes=makes,
                          models=models,
                          years=years,
                          body_types=body_types,
                          current_make=make,
                          current_model=model,
                          current_price=price_range,
                          current_body_type=body_type,
                          current_year=year,
                          current_mileage=mileage,
                          current_sort=sort)

@app.route('/inventory/<int:vehicle_id>')
def vehicle_detail(vehicle_id):
    vehicle = Vehicle.query.get_or_404(vehicle_id)
    
    # Get similar vehicles (same make or model)
    similar_vehicles = Vehicle.query.filter(
        Vehicle.id != vehicle_id,
        Vehicle.status == 'available',
        (Vehicle.make == vehicle.make) | (Vehicle.model == vehicle.model)
    ).limit(3).all()
    
    return render_template('inventory/detail.html', vehicle=vehicle, similar_vehicles=similar_vehicles)

@app.route('/finance')
def finance():
    return render_template('finance.html')

@app.route('/sell-trade')
def sell_trade():
    return render_template('sell_trade.html')

@app.route('/advantage-package')
def advantage_package():
    return render_template('advantage_package.html')

@app.route('/why-buy-from-us')
def why_buy_from_us():
    return render_template('why_buy_from_us.html')

@app.route('/contact')
def contact():
    return render_template('contact/index.html')

@app.route('/contact/submit', methods=['POST'])
def submit_contact():
    try:
        # Get form data
        name = request.form.get('name')
        email = request.form.get('email')
        phone = request.form.get('phone')
        message = request.form.get('message')
        
        # Validate required fields
        if not all([name, email, message]):
            flash('Please fill in all required fields', 'danger')
            return redirect(url_for('contact'))
        
        # Create new inquiry
        new_inquiry = Inquiry(
            name=name,
            email=email,
            phone=phone,
            message=message
        )
        
        db.session.add(new_inquiry)
        db.session.commit()
        
        flash('Your message has been sent! We will contact you shortly.', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Error submitting form: {str(e)}', 'danger')
    
    return redirect(url_for('contact'))

@app.route('/sell-trade/submit', methods=['POST'])
def submit_trade_in():
    try:
        # Get form data
        name = request.form.get('name')
        email = request.form.get('email')
        phone = request.form.get('phone')
        year = request.form.get('year')
        make = request.form.get('make')
        model = request.form.get('model')
        trim = request.form.get('trim')
        mileage = request.form.get('mileage')
        condition = request.form.get('condition')
        vin = request.form.get('vin')
        comments = request.form.get('comments')
        
        # Validate required fields
        if not all([name, email, year, make, model, mileage]):
            flash('Please fill in all required fields', 'danger')
            return redirect(url_for('sell_trade'))
        
        # Create new trade-in
        new_trade_in = TradeIn(
            name=name,
            email=email,
            phone=phone,
            year=year,
            make=make,
            model=model,
            trim=trim,
            mileage=mileage,
            condition=condition,
            vin=vin,
            comments=comments
        )
        
        db.session.add(new_trade_in)
        db.session.commit()
        
        flash('Your trade-in request has been submitted! We will contact you shortly.', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Error submitting form: {str(e)}', 'danger')
    
    return redirect(url_for('sell_trade'))

@app.route('/inventory/inquiry', methods=['POST'])
def submit_vehicle_inquiry():
    try:
        # Get form data
        vehicle_id = request.form.get('vehicle_id')
        name = request.form.get('name')
        email = request.form.get('email')
        phone = request.form.get('phone')
        message = request.form.get('message')
        
        # Validate required fields
        if not all([vehicle_id, name, email, message]):
            flash('Please fill in all required fields', 'danger')
            return redirect(url_for('vehicle_detail', vehicle_id=vehicle_id))
        
        # Create new inquiry
        new_inquiry = Inquiry(
            vehicle_id=vehicle_id,
            name=name,
            email=email,
            phone=phone,
            message=message
        )
        
        db.session.add(new_inquiry)
        db.session.commit()
        
        flash('Your inquiry has been sent! We will contact you shortly.', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Error submitting inquiry: {str(e)}', 'danger')
    
    return redirect(url_for('vehicle_detail', vehicle_id=vehicle_id))

@app.route('/privacy-policy')
def privacy_policy():
    return render_template('privacy_policy.html')

@app.route('/terms-of-service')
def terms_of_service():
    return render_template('terms_of_service.html')

# Admin routes
@app.route('/admin')
def admin_login():
    if 'user_id' in session:
        return redirect(url_for('admin_dashboard'))
    return render_template('admin/login.html')

@app.route('/admin/login', methods=['POST'])
def admin_login_post():
    username = request.form.get('username')
    password = request.form.get('password')
    
    user = User.query.filter_by(username=username).first()
    
    if not user or not check_password_hash(user.password_hash, password):
        flash('Please check your login details and try again.', 'danger')
        return redirect(url_for('admin_login'))
    
    session['user_id'] = user.id
    session['user_role'] = user.role
    
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/logout')
def admin_logout():
    session.pop('user_id', None)
    session.pop('user_role', None)
    return redirect(url_for('admin_login'))

@app.route('/admin/dashboard')
def admin_dashboard():
    if 'user_id' not in session:
        return redirect(url_for('admin_login'))
    
    # Get counts for dashboard
    vehicle_count = Vehicle.query.count()
    available_count = Vehicle.query.filter_by(status='available').count()
    inquiry_count = Inquiry.query.filter_by(status='new').count()
    trade_in_count = TradeIn.query.filter_by(status='new').count()
    
    # Get recent inquiries
    recent_inquiries = Inquiry.query.order_by(Inquiry.created_at.desc()).limit(5).all()
    
    # Get recent trade-ins
    recent_trade_ins = TradeIn.query.order_by(TradeIn.created_at.desc()).limit(5).all()
    
    return render_template('admin/dashboard.html', 
                          vehicle_count=vehicle_count,
                          available_count=available_count,
                          inquiry_count=inquiry_count,
                          trade_in_count=trade_in_count,
                          recent_inquiries=recent_inquiries,
                          recent_trade_ins=recent_trade_ins)

@app.route('/admin/vehicles')
def admin_vehicles():
    if 'user_id' not in session:
        return redirect(url_for('admin_login'))
    
    vehicles = Vehicle.query.order_by(Vehicle.created_at.desc()).all()
    return render_template('admin/vehicles/index.html', vehicles=vehicles)

@app.route('/admin/vehicles/add')
def admin_vehicles_add():
    if 'user_id' not in session:
        return redirect(url_for('admin_login'))
    
    return render_template('admin/vehicles/add.html')

@app.route('/admin/vehicles/edit/<int:vehicle_id>')
def admin_vehicles_edit(vehicle_id):
    if 'user_id' not in session:
        return redirect(url_for('admin_login'))
    
    vehicle = Vehicle.query.get_or_404(vehicle_id)
    return render_template('admin/vehicles/edit.html', vehicle=vehicle)

@app.route('/admin/inquiries')
def admin_inquiries():
    if 'user_id' not in session:
        return redirect(url_for('admin_login'))
    
    inquiries = Inquiry.query.order_by(Inquiry.created_at.desc()).all()
    return render_template('admin/inquiries.html', inquiries=inquiries)

@app.route('/admin/trade-ins')
def admin_trade_ins():
    if 'user_id' not in session:
        return redirect(url_for('admin_login'))
    
    trade_ins = TradeIn.query.order_by(TradeIn.created_at.desc()).all()
    return render_template('admin/trade_ins.html', trade_ins=trade_ins)

@app.route('/admin/settings')
def admin_settings():
    if 'user_id' not in session:
        return redirect(url_for('admin_login'))
    
    settings = SiteSettings.query.all()
    return render_template('admin/settings.html', settings=settings)

@app.route('/admin/users')
def admin_users():
    if 'user_id' not in session or session.get('user_role') != 'admin':
        return redirect(url_for('admin_login'))
    
    users = User.query.all()
    return render_template('admin/users.html', users=users)

# API routes for AJAX calls
@app.route('/api/vehicles/save', methods=['POST'])
def api_vehicles_save():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Not authorized'}), 401
    
    try:
        data = request.form
        vehicle_id = data.get('id')
        
        if vehicle_id:
            # Update existing vehicle
            vehicle = Vehicle.query.get_or_404(vehicle_id)
        else:
            # Create new vehicle
            vehicle = Vehicle()
            vehicle.stock_number = f"BE{uuid.uuid4().hex[:6].upper()}"
        
        # Update vehicle data
        vehicle.vin = data.get('vin')
        vehicle.year = data.get('year')
        vehicle.make = data.get('make')
        vehicle.model = data.get('model')
        vehicle.trim = data.get('trim')
        vehicle.body_type = data.get('body_type')
        vehicle.color = data.get('color')
        vehicle.interior_color = data.get('interior_color')
        vehicle.mileage = data.get('mileage')
        vehicle.price = data.get('price')
        vehicle.description = data.get('description')
        vehicle.features = data.get('features')
        vehicle.engine = data.get('engine')
        vehicle.transmission = data.get('transmission')
        vehicle.drivetrain = data.get('drivetrain')
        vehicle.fuel_type = data.get('fuel_type')
        vehicle.mpg_city = data.get('mpg_city')
        vehicle.mpg_highway = data.get('mpg_highway')
        vehicle.status = data.get('status')
        vehicle.is_featured = True if data.get('is_featured') == 'true' else False
        
        db.session.add(vehicle)
        db.session.commit()
        
        # Handle photo uploads
        photos = request.files.getlist('photos')
        for photo in photos:
            if photo and allowed_file(photo.filename):
                filename = secure_filename(photo.filename)
                unique_filename = f"{uuid.uuid4().hex}_{filename}"
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], 'vehicles', unique_filename)
                photo.save(file_path)
                
                # Create photo record
                vehicle_photo = VehiclePhoto(
                    vehicle_id=vehicle.id,
                    file_path=f"uploads/vehicles/{unique_filename}",
                    is_primary=False
                )
                db.session.add(vehicle_photo)
        
        # Set primary photo if specified
        primary_photo_id = data.get('primary_photo_id')
        if primary_photo_id:
            # Reset all photos to non-primary
            VehiclePhoto.query.filter_by(vehicle_id=vehicle.id).update({'is_primary': False})
            
            # Set selected photo as primary
            photo = VehiclePhoto.query.get(primary_photo_id)
            if photo:
                photo.is_primary = True
        
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Vehicle saved successfully', 'id': vehicle.id})
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': f'Error: {str(e)}'}), 500

@app.route('/api/photos/edit', methods=['POST'])
def api_photos_edit():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Not authorized'}), 401
    
    try:
        photo_id = request.form.get('photo_id')
        edit_type = request.form.get('edit_type')
        
        photo = VehiclePhoto.query.get_or_404(photo_id)
        
        if edit_type == 'delete':
            # Delete the photo file
            file_path = os.path.join(app.root_path, 'static', photo.file_path)
            if os.path.exists(file_path):
                os.remove(file_path)
            
            # Delete the database record
            db.session.delete(photo)
            db.session.commit()
            
            return jsonify({'success': True, 'message': 'Photo deleted successfully'})
        
        elif edit_type == 'primary':
            # Reset all photos to non-primary
            VehiclePhoto.query.filter_by(vehicle_id=photo.vehicle_id).update({'is_primary': False})
            
            # Set selected photo as primary
            photo.is_primary = True
            db.session.commit()
            
            return jsonify({'success': True, 'message': 'Primary photo set successfully'})
        
        return jsonify({'success': False, 'message': 'Invalid edit type'}), 400
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': f'Error: {str(e)}'}), 500

@app.route('/api/inquiries/update', methods=['POST'])
def api_inquiries_update():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Not authorized'}), 401
    
    try:
        inquiry_id = request.form.get('inquiry_id')
        status = request.form.get('status')
        
        inquiry = Inquiry.query.get_or_404(inquiry_id)
        inquiry.status = status
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Inquiry updated successfully'})
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': f'Error: {str(e)}'}), 500

@app.route('/api/trade-ins/update', methods=['POST'])
def api_trade_ins_update():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Not authorized'}), 401
    
    try:
        trade_in_id = request.form.get('trade_in_id')
        status = request.form.get('status')
        
        trade_in = TradeIn.query.get_or_404(trade_in_id)
        trade_in.status = status
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Trade-in updated successfully'})
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': f'Error: {str(e)}'}), 500

@app.route('/api/settings/update', methods=['POST'])
def api_settings_update():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Not authorized'}), 401
    
    try:
        settings = request.form
        
        for key, value in settings.items():
            setting = SiteSettings.query.filter_by(setting_name=key).first()
            
            if setting:
                setting.setting_value = value
            else:
                setting = SiteSettings(setting_name=key, setting_value=value)
                db.session.add(setting)
        
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Settings updated successfully'})
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': f'Error: {str(e)}'}), 500

@app.route('/api/users/save', methods=['POST'])
def api_users_save():
    if 'user_id' not in session or session.get('user_role') != 'admin':
        return jsonify({'success': False, 'message': 'Not authorized'}), 401
    
    try:
        data = request.form
        user_id = data.get('id')
        
        if user_id:
            # Update existing user
            user = User.query.get_or_404(user_id)
        else:
            # Create new user
            user = User()
            user.password_hash = generate_password_hash(data.get('password'))
        
        # Update user data
        user.username = data.get('username')
        user.email = data.get('email')
        user.first_name = data.get('first_name')
        user.last_name = data.get('last_name')
        user.role = data.get('role')
        
        # Update password if provided
        if data.get('password') and user_id:
            user.password_hash = generate_password_hash(data.get('password'))
        
        db.session.add(user)
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'User saved successfully', 'id': user.id})
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': f'Error: {str(e)}'}), 500

@app.route('/api/users/delete', methods=['POST'])
def api_users_delete():
    if 'user_id' not in session or session.get('user_role') != 'admin':
        return jsonify({'success': False, 'message': 'Not authorized'}), 401
    
    try:
        user_id = request.form.get('user_id')
        
        # Prevent deleting yourself
        if int(user_id) == session.get('user_id'):
            return jsonify({'success': False, 'message': 'Cannot delete your own account'}), 400
        
        user = User.query.get_or_404(user_id)
        db.session.delete(user)
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'User deleted successfully'})
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': f'Error: {str(e)}'}), 500

# AI Photo Editing API
@app.route('/api/photos/ai-edit', methods=['POST'])
def api_photos_ai_edit():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Not authorized'}), 401
    
    try:
        photo_id = request.form.get('photo_id')
        edit_type = request.form.get('edit_type')
        
        photo = VehiclePhoto.query.get_or_404(photo_id)
        
        # Get the photo file path
        original_path = os.path.join(app.root_path, 'static', photo.file_path)
        
        if edit_type == 'background':
            # Get the background image
            background_id = request.form.get('background_id')
            background = BackgroundImage.query.get_or_404(background_id)
            background_path = os.path.join(app.root_path, 'static', background.file_path)
            
            # Generate a new filename
            filename = os.path.basename(photo.file_path)
            new_filename = f"edited_{uuid.uuid4().hex[:6]}_{filename}"
            new_path = os.path.join(app.config['UPLOAD_FOLDER'], 'vehicles', new_filename)
            
            # Perform background replacement (simplified for demo)
            # In a real implementation, this would use OpenCV or similar for background replacement
            import shutil
            shutil.copy(original_path, os.path.join(app.root_path, 'static', new_path))
            
            # Create a new photo record
            new_photo = VehiclePhoto(
                vehicle_id=photo.vehicle_id,
                file_path=f"uploads/vehicles/{new_filename}",
                is_primary=False
            )
            db.session.add(new_photo)
            db.session.commit()
            
            return jsonify({
                'success': True, 
                'message': 'Background replaced successfully',
                'photo_id': new_photo.id,
                'file_path': new_photo.file_path
            })
        
        elif edit_type == 'enhance':
            # Get enhancement parameters
            brightness = float(request.form.get('brightness', 0))
            contrast = float(request.form.get('contrast', 0))
            saturation = float(request.form.get('saturation', 0))
            
            # Generate a new filename
            filename = os.path.basename(photo.file_path)
            new_filename = f"enhanced_{uuid.uuid4().hex[:6]}_{filename}"
            new_path = os.path.join(app.config['UPLOAD_FOLDER'], 'vehicles', new_filename)
            
            # Perform image enhancement (simplified for demo)
            # In a real implementation, this would use PIL or OpenCV for image enhancement
            import shutil
            shutil.copy(original_path, os.path.join(app.root_path, 'static', new_path))
            
            # Create a new photo record
            new_photo = VehiclePhoto(
                vehicle_id=photo.vehicle_id,
                file_path=f"uploads/vehicles/{new_filename}",
                is_primary=False
            )
            db.session.add(new_photo)
            db.session.commit()
            
            return jsonify({
                'success': True, 
                'message': 'Image enhanced successfully',
                'photo_id': new_photo.id,
                'file_path': new_photo.file_path
            })
        
        return jsonify({'success': False, 'message': 'Invalid edit type'}), 400
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': f'Error: {str(e)}'}), 500

@app.route('/api/backgrounds')
def api_backgrounds():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Not authorized'}), 401
    
    backgrounds = BackgroundImage.query.all()
    background_list = [{'id': bg.id, 'name': bg.name, 'file_path': bg.file_path} for bg in backgrounds]
    
    return jsonify({'success': True, 'backgrounds': background_list})

@app.route('/api/backgrounds/upload', methods=['POST'])
def api_backgrounds_upload():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Not authorized'}), 401
    
    try:
        name = request.form.get('name')
        file = request.files.get('file')
        
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            unique_filename = f"{uuid.uuid4().hex}_{filename}"
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], 'backgrounds', unique_filename)
            file.save(os.path.join(app.root_path, 'static', file_path))
            
            # Create background record
            background = BackgroundImage(
                name=name,
                file_path=f"uploads/backgrounds/{unique_filename}"
            )
            db.session.add(background)
            db.session.commit()
            
            return jsonify({
                'success': True, 
                'message': 'Background uploaded successfully',
                'id': background.id,
                'file_path': background.file_path
            })
        
        return jsonify({'success': False, 'message': 'Invalid file'}), 400
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': f'Error: {str(e)}'}), 500

# Helper functions
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Context processors
@app.context_processor
def inject_current_year():
    return {'current_year': datetime.now().year}

# Main entry point
if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # Create database tables
        
        # Create admin user if it doesn't exist
        admin = User.query.filter_by(username='admin').first()
        if not admin:
            admin = User(
                username='admin',
                email='admin@beauto.com',
                password_hash=generate_password_hash('admin123'),
                first_name='Admin',
                last_name='User',
                role='admin'
            )
            db.session.add(admin)
            db.session.commit()
            print('Admin user created successfully!')
    
    app.run(host='0.0.0.0', port=5000, debug=True)
