#!/bin/bash

# Create necessary directories for uploads
mkdir -p src/static/uploads/vehicles
mkdir -p src/static/uploads/backgrounds

# Create a default admin user
python3 -c "
from src.main import app, db
from src.models.models import User
from werkzeug.security import generate_password_hash
import os

with app.app_context():
    # Create tables
    db.create_all()
    
    # Check if admin user exists
    admin = User.query.filter_by(username='admin').first()
    
    if not admin:
        # Create admin user
        admin = User(
            username='admin',
            email='admin@beauto.com',
            password_hash=generate_password_hash('admin123'),
            first_name='Admin',
            last_name='User',
            role='admin'
        )
        db.session.add(admin)
        db.session.commit()
        print('Admin user created successfully!')
    else:
        print('Admin user already exists!')
"

# Create sample background images directory
mkdir -p src/static/images/backgrounds

echo "Setup completed successfully!"
